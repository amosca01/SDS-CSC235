

// event listenser and handler for rating selection  
const ratingSelection = d3.select("#rating"); 

ratingSelection.on('change', (event) => {
    const selectedValue = event.target.value;
    // data to send to server
    const dataToSend = {rating: selectedValue}; 
    // pass selection to server
    fetch('http://localhost:8000/api/data', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        }, 
        body: JSON.stringify(dataToSend),
    })
    .then(response => response.json())
    .then(data => {
        // fetch data from server 
        fetchServerData().then((fetchResponse) => {
            drawVis(fetchResponse.data);
        });  
    })
    .catch((error) => {
        console.log('Error: ', error); 
    });   
}); 

// To get data from server
async function fetchServerData() {
    try {
        const response = await fetch('/api/data'); 
        if (!response.ok) {
            throw new Error('Network response was not ok'); 
        }
        const data = await response.json(); 
        return data; 
    } catch (error) {
        console.error("There was a problem with your fetch: ", error); 
    }
}

// TODO: Build your visualization here
async function drawVis(myData) {

    let margin = 50;
    let width = 500;
    let height = 500; 

    d3.select("#frame").html("<h2>Runtime vs. Year for Selected Rating</h2>"); 

    let svg = d3.select("#frame")
                .append("svg")
                    .attr("width", (width + margin*2))
                    .attr("height", (height + margin*2))
                    .append("g")
                        .attr("transform", `translate(${margin},${margin})`); 

    //x axis
    let x = d3.scaleLinear()
                .domain([d3.min(myData, d => +d.year), d3.max(myData, d => +d.year)])
                .range([0, width]);
    svg.append("g")
        .attr("transform", `translate(0,${height})`)
        .call(d3.axisBottom(x).tickFormat(d3.format("d"))); 

    svg.append("text")
            .attr("text-anchor", "middle") 
            .attr("x", width / 2) 
            .attr("y", height + margin / 2 + 10) 
            .text("Year"); 

    //y axis
    let y = d3.scaleLinear()
                .domain([0, d3.max(myData, d => +d.runtime)])
                .range([height, 0]); 
    svg.append("g")
        .call(d3.axisLeft(y));

    svg.append("text") 
            .attr("text-anchor", "middle") 
            .attr("transform", "rotate(-90)") 
            .attr("y", -margin + 20) 
            .attr("x", -height / 2) 
            .text("Runtime"); 

    //add points 
    svg.append("g")
        .selectAll("circle")
        .data(myData)
        .join("circle")
            .attr("cx", d => { return x(d.year); })
            .attr("cy", d => { return y(d.runtime); })
            .attr("r", 2)
            .style("fill", "#69b3a2"); 
} 



























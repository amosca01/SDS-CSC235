const { MongoClient } = require('mongodb'); 

const uri = "mongodb+srv://amosca_db_user:69czzkwwjptzFr9g@cluster0.65k2vqh.mongodb.net/?appName=Cluster0";
const client = new MongoClient(uri);

// Connect to the MongoDB server
async function connectToMongoDB() {
    // Create a new MongoClient
    try {
        await client.connect();
        console.log('Connected to MongoDB');
        return client.db('sample_mflix');
    } catch (error) {
        console.error('Error connecting to MongoDB:', error);
        throw error;
    } 
}

module.exports = connectToMongoDB;
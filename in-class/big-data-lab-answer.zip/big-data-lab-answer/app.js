// app.js 

// Set up server for website 
const express = require('express')
const path = require('path');
const app = express();
const connectToMongoDB = require('./server'); 
const PORT = 8000; 

let currRating = ''; 

app.use(express.json()); // so we can parse JSON 
app.use(express.static(path.join(__dirname, 'public'))); // to serve from public folder

// To get selected rating from front end 
app.post('/api/data', (req, res) => {
    const clientData = req.body; 
    currRating = clientData["rating"]; 
    res.status(200).json({
        message: 'Data received sucessfully!',
        yourData: clientData
    });
}); 

// To send filtered data to front end 
app.get('/api/data', (req, res) => {
    
    getMoviesByRating(currRating)
        .then((movieData) => {
            const serverData = {
                message: "Server data sent!",
                data: movieData,
            };
            res.json(serverData); 
        }); 
}); 

// Start the app 
app.listen(PORT, () => {
    console.log(`Server is running on PORT ${PORT}`)
}); 

// Function to query datbase
async function getMoviesByRating(selectedRating) {

    if (selectedRating == '') {
        console.log("No rating selection"); 
        return []; 
    }

    try {
        const db = await connectToMongoDB(); 
        const movies = db.collection('movies');

        // Query for movies that have given rating
        const query = { rated: selectedRating };
        const sortFields = { title: 1 }; // sort by title
        const projectFields = {  _id: 0, 
                             title: 1, 
                             runtime: 1, 
                             rated: 1, 
                             imdb: 1, 
                             year: 1 
                         }; // fields to keep in returned data

        // Execute query 
        const cursor = movies.find(query).sort(sortFields).project(projectFields);

        // Print a message if no documents were found
        if ((await movies.countDocuments(query)) === 0) {
          console.log("No documents found!");
        }

        // Print results
        // TODO: Modify body of for loop to create a dataset to pass to the front end 
        let dataToReturn = []; 
        for await (const doc of cursor) {
          dataToReturn.push(doc); 
        }
        return dataToReturn; 

    } catch (error) {
        console.error('Error :', error);
        throw error;
    }
}


// event listenser and handler for rating selection  
const ratingSelection = d3.select("#rating"); 

ratingSelection.on('change', (event) => {
    const selectedValue = event.target.value;
    // data to send to server
    const dataToSend = {rating: selectedValue}; 
    // pass selection to server
    fetch('http://localhost:8000/api/data', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        }, 
        body: JSON.stringify(dataToSend),
    })
    .then(response => response.json())
    .then(data => {
        console.log('Response from server: ', data);
        // fetch data from server 
        fetchServerData().then((fetchResponse) => {
            drawVis(fetchResponse.data);
        });  
    })
    .catch((error) => {
        console.log('Error: ', error); 
    });   
}); 

// To get data from server
async function fetchServerData() {
    try {
        const response = await fetch('/api/data'); 
        if (!response.ok) {
            throw new Error('Network response was not ok'); 
        }
        const data = await response.json(); 
        console.log("Fetching server data"); 
        return data; 
    } catch (error) {
        console.error("There was a problem with your fetch: ", error); 
    }
}

// TODO: Build your visualization here
async function drawVis(myData) {
    console.log("Data passed to drawVis(): ", myData); 
}
 